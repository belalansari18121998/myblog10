package com.myblog10;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Myblog10Application {

	public static void main(String[] args) {
		SpringApplication.run(Myblog10Application.class, args);
	}

}
